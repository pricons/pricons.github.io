# Pricons

Pricons (PRIde ICONS) is a tool for more pride emojis on all sites, because unicode won't do it.